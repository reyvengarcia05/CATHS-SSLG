Serve a Knowledge assets

Recommended repository path:
assets/serve-a-knowledge/<filename>

Included:
- restaurant.png
- bear1.png, bear2.png, bear3.png
- timer.png
- face_star.png, face_happy.png, face_sad.png
- heart.png
- jar.png, label.png, exp_text.png
- arrow.png
- bubble-yellow.png, bubble-orange.png, bubble-blue.png
